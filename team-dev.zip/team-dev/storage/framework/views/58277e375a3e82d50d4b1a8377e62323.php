

<?php $__env->startSection('content'); ?>
<div class="auth-bg">
    <div class="auth-card">
        <h2 class="auth-title">サインアップ</h2>
        <form method="POST" action="<?php echo e(route('register')); ?>" class="auth-form">
            <?php echo csrf_field(); ?>
            <div class="auth-group">
                <label for="auth-name">名前</label>
                <input type="text" id="auth-name" name="name" class="auth-input" required value="<?php echo e(old('name')); ?>">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="auth-error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="auth-group">
                <label for="auth-email">メールアドレス</label>
                <input type="email" id="auth-email" name="email" class="auth-input" required value="<?php echo e(old('email')); ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="auth-error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="auth-group">
                <label for="auth-password">パスワード</label>
                <input type="password" id="auth-password" name="password" class="auth-input" required>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="auth-error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="auth-group">
                <label for="auth-password-confirm">パスワード（確認用）</label>
                <input type="password" id="auth-password-confirm" name="password_confirmation" class="auth-input" required>
            </div>
            <button type="submit" class="auth-btn">登録する</button>
        </form>
        <div class="auth-bottom">
            <a href="<?php echo e(route('login')); ?>" class="auth-link">すでにアカウントがある方はこちら</a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC_User\Desktop\アプレンティス\team-2\team-dev\resources\views/auth/register.blade.php ENDPATH**/ ?>