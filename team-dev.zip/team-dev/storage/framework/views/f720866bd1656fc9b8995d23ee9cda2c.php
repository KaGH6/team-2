<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="route-daily-complete" content="<?php echo e(route('daily-challenges.complete')); ?>">
    <meta name="route-daily-change" content="<?php echo e(route('daily-challenges.change')); ?>">
    <meta name="route-logout" content="<?php echo e(route('logout')); ?>">
    <meta name="route-login" content="<?php echo e(route('login')); ?>">
    <meta name="route-weight-store" content="<?php echo e(route('weight.store')); ?>">

    <?php if(isset($events)): ?>
    <script>
        window._calendarEvents = <?php echo json_encode($events, 15, 512) ?>;
    </script>
    <?php endif; ?>

    <title><?php echo $__env->yieldContent('title', 'MyApp'); ?></title>

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css">

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/css/sp.css', 'resources/js/app.js']); ?>
</head>

<body>
    <?php if(!in_array(Route::currentRouteName(), ['login', 'register'])): ?>
    <header class="header">
        <div class="header__container">
            <h1 class="header__logo"><a href="/"></a></h1>
            <input type="checkbox" id="check">
            <label for="check" class="hamburger">
                <span></span>
            </label>
            <nav class="nav">
                <ul class="nav__list">
                    <li class="nav__item"><a href="./">ホーム</a></li>
                    <li class="nav__item"><a href="./weight">体重管理</a></li>
                    <li class="nav__item"><button id="logoutBtn">ログアウト</button></li>
                </ul>
            </nav>
        </div>
    </header>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://unpkg.com/js-circle-progress/dist/circle-progress.min.js" type="module"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\Users\PC_User\Desktop\アプレンティス\team-2\team-dev\resources\views/layouts/app.blade.php ENDPATH**/ ?>